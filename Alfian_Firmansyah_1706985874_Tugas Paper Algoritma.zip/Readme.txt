comparison.cpp adalah main program untuk membandingkan algoritma
random.cpp adalah program untuk menggenerate list data
random.dat adalah file data.